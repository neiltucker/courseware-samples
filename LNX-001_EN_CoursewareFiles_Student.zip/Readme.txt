These are the student materials.  Please contact us for access to the instructor files which include PowerPoints, Trainer PDFs, Trainer Preparation Guide and Capstone resources:
https://www.coursewarestudio.ai
